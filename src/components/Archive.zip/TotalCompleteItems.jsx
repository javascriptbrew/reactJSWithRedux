import React from 'react';

const TotalCompleteItems = () => {
	return <h4 className='mt-3'>Total Complete Items: 5</h4>;
};

export default TotalCompleteItems;
